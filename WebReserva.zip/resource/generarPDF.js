// generarPDF.js
function generarPDF() {
    // Obtener los valores de los campos de entrada
  var nombre = document.getElementById('nombre').value;
    var segundo = document.getElementById('segundo').value;
    var apellido = document.getElementById('apellido').value;
    var telefono = document.getElementById('telefono').value;
    var fecha = document.getElementById('fecha').value;
    var horaInicio = document.getElementById('horaInicio').value;
    var horaFin = document.getElementById('horaFin').value;
    var turnos = document.getElementById('turnos').value;
    var calle = document.getElementById('calle').value;
    var colonia = document.getElementById('colonia').value;
    var numExterno = document.getElementById('numExterno').value;
    var precioFinal = document.getElementById('precioFinal').value;
    var porcentaje1 = document.getElementById('porcentaje1').value;
    var porcentaje2 = document.getElementById('porcentaje2').value;
    var precioPorcentaje1 = document.getElementById('precioPorcentaje1').value;
    var precioPorcentaje2 = document.getElementById('precioPorcentaje2').value;
    var precioLetra = document.getElementById('precioLetra').value;

    // Formatear la fecha en el formato deseado (dd, MM, yyyy)
    var fechaParts = fecha.split('-');
    var fechaFormateada = fechaParts[2] + ' del mes ' + fechaParts[1] + ' del año ' + fechaParts[0];

    // Crear un nuevo objeto de ventana emergente
    var ventanaEmergente = window.open('', '', 'width=600,height=600');

    // Construir el contenido HTML en la ventana emergente
    var contenidoHTML = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
            <title>Contrato de Servicio - Banda Sinaloense</title>
        </head>
        <body>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-left" style="color: red;">
                        <p>Folio 8901</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 text-center" style="font: bold;">
                        <p>La Mejor Banda Sinaloense</p>
                        <p>Banda Grupo Fuerte</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 text-right">
                        <p>CDMX 21/09/2023</p>
                        <p>NOMBRE: ${nombre} ${segundo} ${apellido}</p>
                        <p>Teléfono: ${telefono}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 text-left">
                        <p>Por medio de la presente hago constar que el Sr.(a) de nombre:</p>
                        <p>${nombre} ${segundo} ${apellido}</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <p>Solicito los servicios de Banda Sinaloense</p>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <!-- Utiliza las variables nombre, segundo, apellido, etc., en lugar de valores estáticos -->
                        <p>El evento será con 12 elementos uniformados con audio para el cantante. El servicio musical se prestará durante dos turnos de una hora completa, llegaríamos al evento 10 o 15 minutos antes del evento cualquier percance el representante de la banda le hablaría por teléfono al cliente al número que proporcionó, en caso de llegar tarde se le repondrá el tiempo perdido al cliente.</p>
                        <p>Una vez firmado el contrato se contemplará, pero se apartará hasta que este junto con el anticipo y no se podrá faltar a su evento, En caso de no asistir se le compensará al cliente con: una hora gratis en caso requerir el evento todavía o con la devolución de su dinero y un descuento para un futuro evento, En el caso de que el cliente requiera algún cambio estará sujeto a disponibilidad.</p>
                        <p>El evento será:</p>
                        <p>Para el día ${fechaFormateada} iniciando el evento a las ${horaInicio} y terminando a las ${horaFin}</p>
                        <p>El lugar de la presentación del servicio será en:</p>
                        <p>${calle} ${numExterno} ${colonia}</p>
                        <p>El solicitante se compromete a pagar la cantidad de $${precioFinal} pesos mexicanos.  Cantidad con letra: ${precioLetra} pesos mexicanos.</p>
                        <p></p>
                        <p>Dicha cantidad será pagada de la siguiente manera: ${porcentaje1}% de anticipo y $${porcentaje2}% al llegar al evento antes de comenzar.</p>
                        <p>A) $${precioPorcentaje1} pesos a la firma del representante</p>
                        <p>B) $${precioPorcentaje2} pesos el día del evento al llegar antes de comenzar</p>
                        
                    </div>
                </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
        </body>
        </html>
    `;

    // Escribir el contenido HTML en la ventana emergente
    ventanaEmergente.document.open();
    ventanaEmergente.document.write(contenidoHTML);
    ventanaEmergente.document.close();
}
